"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"

export default function LuxuryBreathingApp() {
  const [isActive, setIsActive] = useState(false)
  const [currentPhase, setCurrentPhase] = useState("Ready")
  const [protocol, setProtocol] = useState("478")
  const [customTiming, setCustomTiming] = useState({ inhale: 4, hold: 7, exhale: 8 })
  const [soundEnabled, setSoundEnabled] = useState(false)
  const [binauralEnabled, setBinauralEnabled] = useState(false)
  const [healingEnabled, setHealingEnabled] = useState(false)
  const [currentCycle, setCurrentCycle] = useState(0)
  const [totalCycles, setTotalCycles] = useState(4)
  const [progress, setProgress] = useState(0)
  const [phaseProgress, setPhaseProgress] = useState(0)
  const [showNav, setShowNav] = useState(true)
  const [lastScrollY, setLastScrollY] = useState(0)
  const [showConsentModal, setShowConsentModal] = useState(false)
  const [hasConsented, setHasConsented] = useState(false)
  const [hasScrolledToBottom, setHasScrolledToBottom] = useState(false)

  const circleRef = useRef<HTMLDivElement>(null)
  const intervalRef = useRef<NodeJS.Timeout | null>(null)
  const phaseTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const progressRef = useRef<NodeJS.Timeout | null>(null)
  const isActiveRef = useRef(false)
  const sharedAudioContextRef = useRef<AudioContext | null>(null)
  const currentAudioNodesRef = useRef<{
    healing: { oscillator: OscillatorNode; gain: GainNode } | null
    binaural: { leftOsc: OscillatorNode; rightOsc: OscillatorNode; leftGain: GainNode; rightGain: GainNode } | null
  }>({ healing: null, binaural: null })

  const modalContentRef = useRef<HTMLDivElement>(null)

  const phaseIndexRef = useRef(0)
  const protocolRef = useRef(protocol)
  const customTimingRef = useRef(customTiming)
  const totalCyclesRef = useRef(totalCycles)
  const phaseDurationsRef = useRef<number[]>([])

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY
      setShowNav(currentScrollY < lastScrollY || currentScrollY < 50)
      setLastScrollY(currentScrollY)
    }

    window.addEventListener("scroll", handleScroll, { passive: true })
    return () => window.removeEventListener("scroll", handleScroll)
  }, [lastScrollY])

  useEffect(() => {
    // Check if user has already consented in this session
    const consent = sessionStorage.getItem("qalm-consent")
    if (consent === "true") {
      setHasConsented(true)
    } else {
      setShowConsentModal(true)
    }
  }, [])

  const handleScroll = () => {
    if (modalContentRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = modalContentRef.current
      const isScrolledToBottom = scrollTop + clientHeight >= scrollHeight - 10
      setHasScrolledToBottom(isScrolledToBottom)
    }
  }

  const handleConsent = (isOfAge: boolean, acceptsTerms: boolean) => {
    if (isOfAge && acceptsTerms && hasScrolledToBottom) {
      setHasConsented(true)
      setShowConsentModal(false)
      sessionStorage.setItem("qalm-consent", "true")
    } else if (!hasScrolledToBottom) {
      alert("Please scroll through the complete Privacy Policy & Terms of Use before accepting.")
    } else {
      // Redirect or show message if they don't consent
      alert("You must be 18+ and agree to the terms to use Qalm™")
    }
  }

  const protocols = {
    "478": {
      inhale: 4,
      hold: 7,
      exhale: 8,
      name: "4-7-8 Technique",
      description: "Deep relaxation & sleep preparation",
      binauralBase: 200,
      binauralBeat: 6,
    },
    box: {
      inhale: 4,
      hold: 4,
      exhale: 4,
      holdEmpty: 4,
      name: "Box Breathing",
      description: "Mental clarity & focus",
      binauralBase: 200,
      binauralBeat: 10,
    },
    coherent: {
      inhale: 5,
      exhale: 5,
      name: "Coherent Breathing",
      description: "Heart rate variability optimization",
      binauralBase: 200,
      binauralBeat: 10,
    },
    physiological: {
      inhale: 4,
      hold: 0,
      exhale: 8,
      name: "Physiological Sigh",
      description: "Rapid stress relief",
      binauralBase: 200,
      binauralBeat: 8,
    },
  }

  const startBreathing = () => {
    setIsActive(true)
    isActiveRef.current = true
    setCurrentCycle(0)
    setProgress(0)
    setPhaseProgress(0)
    phaseIndexRef.current = 0
    protocolRef.current = protocol
    customTimingRef.current = customTiming
    totalCyclesRef.current = totalCycles
    runBreathingCycle()
  }

  const stopBreathing = () => {
    setIsActive(false)
    isActiveRef.current = false
    setCurrentPhase("Ready")
    setProgress(0)
    setPhaseProgress(0)
    if (intervalRef.current) clearInterval(intervalRef.current)
    if (phaseTimeoutRef.current) clearTimeout(phaseTimeoutRef.current)
    if (progressRef.current) clearTimeout(progressRef.current)
    if (sharedAudioContextRef.current) {
      sharedAudioContextRef.current.close()
      sharedAudioContextRef.current = null
    }
    currentAudioNodesRef.current.healing = null
    currentAudioNodesRef.current.binaural = null
  }

  const runBreathingCycle = () => {
    const timing =
      protocolRef.current === "custom"
        ? customTimingRef.current
        : protocols[protocolRef.current as keyof typeof protocols]
    let phaseIndex = phaseIndexRef.current
    const phases =
      protocolRef.current === "box"
        ? ["Inhale", "Hold", "Exhale", "Rest"]
        : protocolRef.current === "coherent"
          ? ["Inhale", "Exhale"]
          : ["Inhale", "Hold", "Exhale"]

    const phaseDurations =
      protocolRef.current === "box"
        ? [timing.inhale, timing.hold, timing.exhale, (timing as any).holdEmpty]
        : protocolRef.current === "coherent"
          ? [timing.inhale, timing.exhale]
          : [timing.inhale, timing.hold || 0, timing.exhale]

    phaseDurationsRef.current = phaseDurations

    const runPhase = () => {
      if (!isActiveRef.current) return

      if (currentAudioNodesRef.current.healing) {
        try {
          currentAudioNodesRef.current.healing.oscillator.stop()
        } catch (e) {}
        currentAudioNodesRef.current.healing = null
      }

      if (currentAudioNodesRef.current.binaural) {
        try {
          currentAudioNodesRef.current.binaural.leftOsc.stop()
          currentAudioNodesRef.current.binaural.rightOsc.stop()
        } catch (e) {}
        currentAudioNodesRef.current.binaural = null
      }

      setCurrentPhase(phases[phaseIndex])
      setPhaseProgress(0)

      const duration = phaseDurations[phaseIndex] * 1000
      const startTime = performance.now()

      const updateProgress = (currentTime: number) => {
        if (!isActiveRef.current) return

        const elapsed = currentTime - startTime
        const newProgress = Math.min((elapsed / duration) * 100, 100)
        setPhaseProgress(newProgress)

        const totalPhases = phases.length * totalCyclesRef.current
        const completedPhases = currentCycle * phases.length + phaseIndex
        const overallProgress = ((completedPhases + newProgress / 100) / totalPhases) * 100
        setProgress(overallProgress)

        if (newProgress < 100 && isActiveRef.current) {
          requestAnimationFrame(updateProgress)
        }
      }
      requestAnimationFrame(updateProgress)

      startCurrentPhaseAudio(duration)

      phaseTimeoutRef.current = setTimeout(() => {
        phaseIndex = (phaseIndex + 1) % phases.length
        phaseIndexRef.current = phaseIndex

        if (phaseIndex === 0) {
          setCurrentCycle((prev) => prev + 1)
          if (currentCycle + 1 >= totalCyclesRef.current) {
            stopBreathing()
            return
          }
        }

        if (isActiveRef.current) {
          runPhase()
        }
      }, duration)
    }

    runPhase()
  }

  useEffect(() => {
    isActiveRef.current = isActive
  }, [isActive])

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if ("vibrate" in navigator) {
        navigator.vibrate(50)
      }

      if (e.code === "Space") {
        e.preventDefault()
        isActive ? stopBreathing() : startBreathing()
      }
      if (e.key >= "1" && e.key <= "4") {
        const protocolKeys = ["478", "box", "coherent", "physiological"]
        setProtocol(protocolKeys[Number.parseInt(e.key) - 1])
        protocolRef.current = protocolKeys[Number.parseInt(e.key) - 1]
      }
      if (e.key === "s" || e.key === "S") {
        toggleSound()
      }
      if (e.key === "b" || e.key === "B") {
        toggleBinaural()
      }
      if (e.key === "h" || e.key === "H") {
        toggleHealing()
      }
      if (e.key === "Escape") {
        stopBreathing()
      }
    }

    window.addEventListener("keydown", handleKeyPress)
    return () => window.removeEventListener("keydown", handleKeyPress)
  }, [isActive, soundEnabled, binauralEnabled, healingEnabled])

  useEffect(() => {
    if (!circleRef.current) return

    const circle = circleRef.current
    let targetScale = 1

    if (currentPhase === "Inhale") {
      targetScale = 1.8
    } else if (currentPhase === "Exhale") {
      targetScale = 0.6
    } else if (currentPhase === "Hold" || currentPhase === "Rest") {
      targetScale = 1.4
    }

    const progress = phaseProgress / 100
    const currentScale = 1 + (targetScale - 1) * progress

    circle.style.transform = `scale(${currentScale})`
  }, [currentPhase, phaseProgress, protocol, customTiming])

  const currentProtocolInfo =
    protocol === "custom"
      ? { name: "Custom Protocol", description: "Personalized breathing pattern" }
      : protocols[protocol as keyof typeof protocols]

  const startCurrentPhaseAudio = async (duration: number) => {
    const audioContext = await initializeAudio()
    if (!audioContext) return

    // Start healing tones if enabled
    if (healingEnabled) {
      try {
        const frequencies = [528, 396, 174, 285]
        const frequency = frequencies[phaseIndexRef.current % frequencies.length]

        const oscillator = audioContext.createOscillator()
        const gainNode = audioContext.createGain()

        oscillator.connect(gainNode)
        gainNode.connect(audioContext.destination)

        oscillator.frequency.setValueAtTime(frequency, audioContext.currentTime)
        oscillator.type = "sine"

        gainNode.gain.setValueAtTime(0, audioContext.currentTime)
        gainNode.gain.linearRampToValueAtTime(0.02, audioContext.currentTime + 0.1)
        gainNode.gain.linearRampToValueAtTime(0.02, audioContext.currentTime + duration / 1000 - 0.1)
        gainNode.gain.linearRampToValueAtTime(0, audioContext.currentTime + duration / 1000)

        oscillator.start(audioContext.currentTime)
        oscillator.stop(audioContext.currentTime + duration / 1000)

        currentAudioNodesRef.current.healing = { oscillator, gain: gainNode }
      } catch (error) {
        console.log("Healing audio error:", error)
      }
    }

    // Start binaural beats if enabled
    if (binauralEnabled) {
      try {
        const protocolInfo = protocols[protocolRef.current as keyof typeof protocols]
        if (protocolInfo) {
          const baseFreq = protocolInfo.binauralBase
          const beatFreq = protocolInfo.binauralBeat

          const leftOsc = audioContext.createOscillator()
          const rightOsc = audioContext.createOscillator()
          const leftGain = audioContext.createGain()
          const rightGain = audioContext.createGain()
          const merger = audioContext.createChannelMerger(2)

          leftOsc.connect(leftGain)
          rightOsc.connect(rightGain)
          leftGain.connect(merger, 0, 0)
          rightGain.connect(merger, 0, 1)
          merger.connect(audioContext.destination)

          leftOsc.frequency.setValueAtTime(baseFreq, audioContext.currentTime)
          rightOsc.frequency.setValueAtTime(baseFreq + beatFreq, audioContext.currentTime)
          leftOsc.type = "sine"
          rightOsc.type = "sine"

          leftGain.gain.setValueAtTime(0, audioContext.currentTime)
          rightGain.gain.setValueAtTime(0, audioContext.currentTime)
          leftGain.gain.linearRampToValueAtTime(0.15, audioContext.currentTime + 0.1)
          rightGain.gain.linearRampToValueAtTime(0.15, audioContext.currentTime + 0.1)
          leftGain.gain.linearRampToValueAtTime(0.15, audioContext.currentTime + duration / 1000 - 0.1)
          rightGain.gain.linearRampToValueAtTime(0.15, audioContext.currentTime + duration / 1000 - 0.1)
          leftGain.gain.linearRampToValueAtTime(0, audioContext.currentTime + duration / 1000)
          rightGain.gain.linearRampToValueAtTime(0, audioContext.currentTime + duration / 1000)

          leftOsc.start(audioContext.currentTime)
          rightOsc.start(audioContext.currentTime)
          leftOsc.stop(audioContext.currentTime + duration / 1000)
          rightOsc.stop(audioContext.currentTime + duration / 1000)

          currentAudioNodesRef.current.binaural = { leftOsc, rightOsc, leftGain, rightGain }
        }
      } catch (error) {
        console.log("Binaural audio error:", error)
      }
    }
  }

  const initializeAudio = async () => {
    if (!sharedAudioContextRef.current) {
      try {
        sharedAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)()
      } catch (error) {
        console.log("Could not create audio context:", error)
        return null
      }
    }

    const audioContext = sharedAudioContextRef.current
    if (audioContext.state === "suspended") {
      try {
        await audioContext.resume()
      } catch (error) {
        console.log("Could not resume audio context:", error)
        return null
      }
    }
    return audioContext
  }

  const toggleSound = async () => {
    setSoundEnabled(!soundEnabled)
  }

  const toggleBinaural = async () => {
    const newState = !binauralEnabled
    setBinauralEnabled(newState)

    if (isActiveRef.current) {
      if (newState) {
        // Start binaural audio for current phase
        const remainingDuration = phaseDurationsRef.current[phaseIndexRef.current] * 1000 * (1 - phaseProgress / 100)
        const audioContext = await initializeAudio()
        if (audioContext) {
          try {
            const protocolInfo = protocols[protocolRef.current as keyof typeof protocols]
            if (protocolInfo) {
              const baseFreq = protocolInfo.binauralBase
              const beatFreq = protocolInfo.binauralBeat

              const leftOsc = audioContext.createOscillator()
              const rightOsc = audioContext.createOscillator()
              const leftGain = audioContext.createGain()
              const rightGain = audioContext.createGain()
              const merger = audioContext.createChannelMerger(2)

              leftOsc.connect(leftGain)
              rightOsc.connect(rightGain)
              leftGain.connect(merger, 0, 0)
              rightGain.connect(merger, 0, 1)
              merger.connect(audioContext.destination)

              leftOsc.frequency.setValueAtTime(baseFreq, audioContext.currentTime)
              rightOsc.frequency.setValueAtTime(baseFreq + beatFreq, audioContext.currentTime)
              leftOsc.type = "sine"
              rightOsc.type = "sine"

              leftGain.gain.setValueAtTime(0, audioContext.currentTime)
              rightGain.gain.setValueAtTime(0, audioContext.currentTime)
              leftGain.gain.linearRampToValueAtTime(0.15, audioContext.currentTime + 0.1)
              rightGain.gain.linearRampToValueAtTime(0.15, audioContext.currentTime + 0.1)
              leftGain.gain.linearRampToValueAtTime(0, audioContext.currentTime + remainingDuration / 1000)

              leftOsc.start(audioContext.currentTime)
              rightOsc.start(audioContext.currentTime)
              leftOsc.stop(audioContext.currentTime + remainingDuration / 1000)
              rightOsc.stop(audioContext.currentTime + remainingDuration / 1000)

              currentAudioNodesRef.current.binaural = { leftOsc, rightOsc, leftGain, rightGain }
            }
          } catch (error) {
            console.log("Binaural audio error:", error)
          }
        }
      } else {
        // Stop current binaural audio immediately
        if (currentAudioNodesRef.current.binaural) {
          try {
            currentAudioNodesRef.current.binaural.leftOsc.stop()
            currentAudioNodesRef.current.binaural.rightOsc.stop()
          } catch (e) {}
          currentAudioNodesRef.current.binaural = null
        }
      }
    }
  }

  const toggleHealing = async () => {
    const newState = !healingEnabled
    setHealingEnabled(newState)

    if (isActiveRef.current) {
      if (newState) {
        // Start healing audio for current phase
        const remainingDuration = phaseDurationsRef.current[phaseIndexRef.current] * 1000 * (1 - phaseProgress / 100)
        const audioContext = await initializeAudio()
        if (audioContext) {
          try {
            const frequencies = [528, 396, 174, 285]
            const frequency = frequencies[phaseIndexRef.current % frequencies.length]

            const oscillator = audioContext.createOscillator()
            const gainNode = audioContext.createGain()

            oscillator.connect(gainNode)
            gainNode.connect(audioContext.destination)

            oscillator.frequency.setValueAtTime(frequency, audioContext.currentTime)
            oscillator.type = "sine"

            gainNode.gain.setValueAtTime(0, audioContext.currentTime)
            gainNode.gain.linearRampToValueAtTime(0.02, audioContext.currentTime + 0.1)
            gainNode.gain.linearRampToValueAtTime(0, audioContext.currentTime + remainingDuration / 1000)

            oscillator.start(audioContext.currentTime)
            oscillator.stop(audioContext.currentTime + remainingDuration / 1000)

            currentAudioNodesRef.current.healing = { oscillator, gain: gainNode }
          } catch (error) {
            console.log("Healing audio error:", error)
          }
        }
      } else {
        // Stop current healing audio immediately
        if (currentAudioNodesRef.current.healing) {
          try {
            currentAudioNodesRef.current.healing.oscillator.stop()
          } catch (e) {}
          currentAudioNodesRef.current.healing = null
        }
      }
    }
  }

  if (showConsentModal) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center p-4">
        <style jsx global>{`
          @import url('https://fonts.googleapis.com/css2?family=Inter:wght@200;300;400;500&family=Playfair+Display:wght@200;300;400;500&display=swap');
          
          .luxury-heading {
            font-family: 'Playfair Display', serif;
            font-weight: 200;
            letter-spacing: -0.02em;
            line-height: 1.1;
          }
          
          .luxury-body {
            font-family: 'Inter', sans-serif;
            font-weight: 300;
            letter-spacing: 0.01em;
            line-height: 1.6;
          }
        `}</style>

        <div className="max-w-4xl w-full h-[90vh] bg-white/8 backdrop-blur-xl rounded-2xl border border-white/15 p-8 flex flex-col">
          <div className="text-center mb-6">
            <h2 className="luxury-heading text-3xl font-light text-white mb-4">Privacy Policy & Terms of Use</h2>
            <p className="luxury-body text-white/80 text-sm leading-relaxed">
              Please read the complete terms below and scroll to the bottom to continue.
            </p>
          </div>

          <div
            ref={modalContentRef}
            onScroll={handleScroll}
            className="flex-1 overflow-y-auto pr-4 space-y-6 luxury-body text-white/90 text-sm leading-relaxed"
            style={{
              scrollbarWidth: "thin",
              scrollbarColor: "rgba(255,255,255,0.3) transparent",
            }}
          >
            <section>
              <h3 className="luxury-heading text-xl font-light text-white mb-3">Introduction</h3>
              <p>
                At BNDR LLC ("BNDR", "we", "us", or "our"), we respect your privacy. Qalm™ is designed to help users
                achieve deep relaxation and sleep preparation through breathing protocols and sound-based techniques. We
                believe in calm, clarity — and complete transparency.
              </p>
              <p className="mt-3">
                This Privacy Policy outlines what information is (and isn't) collected, how it's used, and the
                safeguards in place to protect your experience.
              </p>
            </section>

            <section>
              <h3 className="luxury-heading text-xl font-light text-white mb-3">
                1. No Required Accounts or Identity Tracking
              </h3>
              <p className="mb-3">
                Qalm™ does not require account creation, login, or any personal information to use the app. We do not
                request, collect, or store:
              </p>
              <ul className="list-disc list-inside space-y-1 ml-4 text-white/80">
                <li>Names</li>
                <li>Email addresses</li>
                <li>Location data</li>
                <li>Biometric or health data</li>
                <li>Microphone, camera, or motion sensor inputs</li>
                <li>IP addresses tied to identity</li>
              </ul>
              <p className="mt-3">You may access and use Qalm™ in full without submitting any identifying data.</p>
            </section>

            <section>
              <h3 className="luxury-heading text-xl font-light text-white mb-3">2. Local Storage Only</h3>
              <p>
                All customizations — such as selected breathing protocols, toggle settings (Healing Tones, Binaural
                Beats), or breathing cycle preferences — are stored locally on your device. We do not transmit or sync
                any of this information to external servers.
              </p>
            </section>

            <section>
              <h3 className="luxury-heading text-xl font-light text-white mb-3">3. App Usage Data</h3>
              <p className="mb-3">
                As of this policy's effective date, no analytics or tracking scripts are implemented in Qalm™.
              </p>
              <p className="mb-3">
                In the future, we may integrate basic, privacy-respecting analytics tools (such as Google Analytics or
                similar) to help us understand how the app is used — strictly in aggregate and without personally
                identifiable information. Should this occur:
              </p>
              <ul className="list-disc list-inside space-y-1 ml-4 text-white/80">
                <li>
                  Data collected will include non-identifiable metrics (e.g., feature usage frequency, platform type)
                </li>
                <li>No user profiles, behavioral tracking, or persistent identifiers will be created</li>
                <li>You will be notified through an updated Privacy Policy</li>
              </ul>
            </section>

            <section>
              <h3 className="luxury-heading text-xl font-light text-white mb-3">4. Third-Party Services</h3>
              <p className="mb-3">
                Qalm™ does not rely on third-party platforms or services to function. However, in the event future
                analytics or diagnostics tools are integrated, they will be:
              </p>
              <ul className="list-disc list-inside space-y-1 ml-4 text-white/80">
                <li>Industry-standard platforms with established security practices</li>
                <li>Used exclusively for crash reports or aggregated feature usage</li>
                <li>Bound by agreements prohibiting resale, sharing, or misuse of any data</li>
              </ul>
              <p className="mt-3">We will update this policy to identify any such providers, if applicable.</p>
            </section>

            <section>
              <h3 className="luxury-heading text-xl font-light text-white mb-3">5. Data Security</h3>
              <p className="mb-3">BNDR LLC adheres to security best practices to protect users:</p>
              <ul className="list-disc list-inside space-y-1 ml-4 text-white/80">
                <li>No cloud databases or user-data APIs are integrated</li>
                <li>No external calls to third-party domains for user data transmission</li>
                <li>Local storage is used only for preferences, not identity</li>
                <li>The application is served via secure distribution channels (e.g., verified app stores)</li>
              </ul>
            </section>

            <section>
              <h3 className="luxury-heading text-xl font-light text-white mb-3">6. Children's Privacy</h3>
              <p>
                Qalm™ is not intended for use by children under the age of 13. We do not knowingly collect or store any
                information from minors. If we become aware that we have inadvertently collected data from a child, it
                will be deleted immediately.
              </p>
            </section>

            <section>
              <h3 className="luxury-heading text-xl font-light text-white mb-3">7. Links to External Sites</h3>
              <p>
                The app may include a direct link to our official website (e.g., via a clickable icon or header).
                Interaction with the external site is governed by that website's separate privacy policy.
              </p>
            </section>

            <section>
              <h3 className="luxury-heading text-xl font-light text-white mb-3">8. Wellness & Safety Notice</h3>
              <p>
                Qalm™ provides audio-visual content and guided breathing sequences designed for general relaxation and
                well-being. It is not a medical device and is not intended to diagnose, treat, or prevent any condition.
                Users with respiratory issues, neurological conditions (such as epilepsy), audio sensitivity, or other
                medical concerns should use the App with discretion. Discontinue use if you experience discomfort or
                adverse effects.
              </p>
            </section>

            <section>
              <h3 className="luxury-heading text-xl font-light text-white mb-3">9. Policy Updates</h3>
              <p>
                This Privacy Policy may be updated periodically to reflect feature changes, legal requirements, or
                transparency improvements. We will update the effective date at the top of the page. Continued use of
                Qalm™ after updates constitutes acceptance of the new terms.
              </p>
            </section>

            <section>
              <h3 className="luxury-heading text-xl font-light text-white mb-3">10. Contact</h3>
              <p className="mb-3">
                If you have questions, concerns, or wish to request deletion of any data inadvertently collected, please
                contact:
              </p>
              <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                <p className="font-medium text-white mb-2">BNDR LLC</p>
                <p className="text-white/80 mb-1">
                  ✉️{" "}
                  <a href="mailto:bndrbots@gmail.com" className="hover:text-white transition-colors duration-300">
                    bndrbots@gmail.com
                  </a>
                </p>
                <p className="text-white/80">
                  🖥️{" "}
                  <a
                    href="https://bndrdesigns.carrd.co/#"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-white transition-colors duration-300"
                  >
                    BNDR LLC
                  </a>
                </p>
              </div>
            </section>

            <div className="text-center pt-8 border-t border-white/10">
              <p className="text-white/60 text-xs">© 2025 BNDR LLC. All rights reserved.</p>
              <p className="text-white/60 text-xs mt-2">Last Updated: August 12, 2025</p>
            </div>
          </div>

          <div className="mt-6 pt-6 border-t border-white/15">
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <input
                  type="checkbox"
                  id="age-consent"
                  className="mt-1 w-4 h-4 rounded border-white/30 bg-white/10 text-blue-500 focus:ring-blue-500 focus:ring-2"
                />
                <label htmlFor="age-consent" className="luxury-body text-white/90 text-sm">
                  I am 18 years of age or older and legally able to consent to terms of use
                </label>
              </div>
              <div className="flex items-start space-x-3">
                <input
                  type="checkbox"
                  id="terms-consent"
                  disabled={!hasScrolledToBottom}
                  className={`mt-1 w-4 h-4 rounded border-white/30 bg-white/10 text-blue-500 focus:ring-blue-500 focus:ring-2 ${!hasScrolledToBottom ? "opacity-50 cursor-not-allowed" : ""}`}
                />
                <label
                  htmlFor="terms-consent"
                  className={`luxury-body text-sm ${hasScrolledToBottom ? "text-white/90" : "text-white/50"}`}
                >
                  I agree to the Privacy Policy & Terms of Use for Qalm™
                  {!hasScrolledToBottom && (
                    <span className="block text-xs text-white/40 mt-1">
                      Please scroll to the bottom to enable this option
                    </span>
                  )}
                </label>
              </div>
            </div>

            <div className="flex space-x-3 pt-6">
              <button
                onClick={() => {
                  const ageConsent = (document.getElementById("age-consent") as HTMLInputElement)?.checked
                  const termsConsent = (document.getElementById("terms-consent") as HTMLInputElement)?.checked
                  handleConsent(ageConsent || false, termsConsent || false)
                }}
                disabled={!hasScrolledToBottom}
                className={`flex-1 py-3 px-4 border rounded-xl luxury-body text-sm font-light transition-all duration-300 ${
                  hasScrolledToBottom
                    ? "bg-white/10 hover:bg-white/15 border-white/20 text-white"
                    : "bg-white/5 border-white/10 text-white/50 cursor-not-allowed"
                }`}
              >
                I Agree & Continue
              </button>
              <button
                onClick={() => (window.location.href = "https://bndrdesigns.carrd.co/#")}
                className="flex-1 py-3 px-4 bg-white/5 hover:bg-white/8 border border-white/15 rounded-xl text-white/70 luxury-body text-sm font-light transition-all duration-300"
              >
                Decline & Exit
              </button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (!hasConsented) {
    return null
  }

  return (
    <div className="min-h-screen bg-black text-white overflow-hidden relative">
      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@200;300;400;500&family=Playfair+Display:wght@200;300;400;500&display=swap');
        
        .luxury-heading {
          font-family: 'Playfair Display', serif;
          font-weight: 200;
          letter-spacing: -0.02em;
          line-height: 1.1;
        }
        
        .luxury-body {
          font-family: 'Inter', sans-serif;
          font-weight: 300;
          letter-spacing: 0.01em;
          line-height: 1.5;
        }
        
        .luxury-button {
          font-family: 'Inter', sans-serif;
          font-weight: 300;
          letter-spacing: 0.02em;
        }

        .atomic-toggle {
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
      `}</style>

      <style jsx>{`
        .atomic-toggle-active {
          background: linear-gradient(135deg, #B19CD9 0%, #C8B5DB 100%);
          box-shadow: 0 2px 8px rgba(177, 156, 217, 0.3), inset 0 1px 0 rgba(255,255,255,0.2);
        }
        .atomic-toggle-inactive {
          background: rgba(255,255,255,0.1);
          box-shadow: inset 0 2px 4px rgba(0,0,0,0.2);
        }
      `}</style>

      <div
        className="fixed inset-0 pointer-events-none z-50"
        style={{
          background: `
            linear-gradient(90deg, rgba(255,255,255,0.1) 0%, transparent 1%, transparent 99%, rgba(255,255,255,0.1) 100%),
            linear-gradient(0deg, rgba(255,255,255,0.1) 0%, transparent 1%, transparent 99%, rgba(255,255,255,0.1) 100%
          `,
          boxShadow: `
            inset 0 0 0 1px rgba(255,255,255,0.05),
            inset 0 0 20px rgba(255,255,255,0.02),
            0 0 40px rgba(255,255,255,0.03)
          `,
          borderRadius: "12px",
          margin: "8px",
        }}
      />

      <nav
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-700 ease-out ${
          showNav ? "translate-y-0 opacity-100" : "-translate-y-full opacity-0"
        }`}
        style={{
          background: `linear-gradient(180deg, 
            rgba(0,0,0,0.9) 0%, 
            rgba(0,0,0,0.7) 50%, 
            rgba(0,0,0,0.3) 100%
          )`,
          backdropFilter: "blur(20px) saturate(1.8)",
          borderBottom: "1px solid rgba(255,255,255,0.08)",
        }}
      >
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-8">
              <h1 className="luxury-heading text-2xl font-light text-white">
                Qalm
                <sup
                  className="text-xs md:text-sm text-white ml-0.5 font-light"
                  style={{ fontSize: "0.4em", verticalAlign: "super", lineHeight: 1 }}
                >
                  ™
                </sup>
              </h1>
              <Link
                href="/privacy"
                className="luxury-body text-sm font-light text-white/70 hover:text-white transition-colors duration-300 tracking-wide"
              >
                Privacy Policy & Terms Of Use
              </Link>
            </div>
            <div className="flex items-center space-x-4">
              <a
                href="https://bndrdesigns.carrd.co/#"
                target="_blank"
                rel="noopener noreferrer"
                className="group p-2 rounded-lg bg-white/5 hover:bg-white/10 transition-all duration-300 border border-white/10 hover:border-white/20"
                style={{
                  boxShadow: "0 4px 16px rgba(0,0,0,0.1), inset 0 1px 0 rgba(255,255,255,0.05)",
                }}
              >
                <img
                  src="/images/bndr-logo.png"
                  alt="BNDR Logo"
                  className="w-8 h-8 object-contain opacity-90 group-hover:opacity-100 transition-opacity duration-300"
                />
              </a>
            </div>
          </div>
        </div>
      </nav>

      <div className="absolute inset-0 bg-gradient-to-br from-black via-zinc-950 to-black" />

      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-4 pt-20">
        <div className="text-center mb-16">
          <h1 className="luxury-heading text-4xl md:text-6xl font-light text-white mb-4">
            Qalm
            <sup
              className="text-xs md:text-sm text-white ml-0.5 font-light"
              style={{ fontSize: "0.4em", verticalAlign: "super", lineHeight: 1 }}
            >
              ™
            </sup>
          </h1>
          <p className="luxury-body text-zinc-400 text-lg md:text-xl max-w-md mx-auto leading-relaxed">
            {currentProtocolInfo.description}
          </p>
        </div>

        <div className="relative mb-16">
          <div
            ref={circleRef}
            className="w-64 h-64 md:w-80 md:h-80 rounded-full border border-zinc-800 transition-all duration-1000 ease-out will-change-transform"
            style={{
              background: `radial-gradient(circle at center, 
                rgba(255, 255, 255, 0.04) 0%, 
                rgba(255, 255, 255, 0.02) 50%, 
                rgba(255, 255, 255, 0.01) 100%)`,
              boxShadow: `
                0 0 20px rgba(255, 255, 255, 0.05),
                0 0 40px rgba(255,255,255,0.02),
                inset 0 0 20px rgba(255,255,255,0.02)
              `,
            }}
          />

          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <div className="luxury-heading text-2xl md:text-3xl font-light text-white mb-2">{currentPhase}</div>
              {isActive && (
                <div className="luxury-body text-zinc-400 text-sm">
                  Cycle {currentCycle + 1} of {totalCycles}
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="w-full max-w-lg space-y-8">
          <button
            onClick={isActive ? stopBreathing : startBreathing}
            className="group w-full py-4 px-8 relative overflow-hidden rounded-xl transition-all duration-500 ease-out transform hover:scale-[1.01] active:scale-[0.99]"
            style={{
              background: "linear-gradient(135deg, rgba(255,255,255,0.08) 0%, rgba(255,255,255,0.04) 100%)",
              backdropFilter: "blur(20px) saturate(1.5)",
              border: "1px solid rgba(255,255,255,0.12)",
              boxShadow: `
                0 4px 20px rgba(0,0,0,0.15),
                inset 0 1px 0 rgba(255,255,255,0.1)
              `,
            }}
          >
            <div className="flex items-center justify-center space-x-3">
              <div
                className={`w-2 h-2 rounded-full shadow-lg transition-all duration-300 ${
                  isActive ? "bg-red-400 shadow-red-400/50" : "bg-green-400 shadow-green-400/30"
                }`}
              />
              <span className="luxury-button text-white text-lg tracking-wide">
                {isActive ? "End Session" : "Begin Practice"}
              </span>
            </div>
          </button>

          <div className="text-center">
            <div className="luxury-body text-xs font-light text-white/50 tracking-[0.2em] uppercase mb-3">
              Breathing Protocol
            </div>
            <select
              value={protocol}
              onChange={(e) => {
                setProtocol(e.target.value as keyof typeof protocols)
                protocolRef.current = e.target.value as keyof typeof protocols
              }}
              className="w-full p-4 pr-12 bg-white/6 border border-white/15 rounded-xl backdrop-blur-xl text-white luxury-body text-base focus:bg-white/10 focus:border-white/25 focus:outline-none transition-all duration-300 hover:bg-white/8 appearance-none bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTIiIGhlaWdodD0iOCIgdmlld0JveD0iMCAwIDEyIDgiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxwYXRoIGQ9Ik0xIDFMNiA2TDExIDEiIHN0cm9rZT0icmdiYSgyNTUsMjU1LDI1NSwwLjYpIiBzdHJva2Utd2lkdGg9IjEuNSIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+Cjwvc3ZnPgo=')] bg-no-repeat bg-[position:calc(100%-16px)_center]"
              style={{
                boxShadow: "0 2px 12px rgba(0,0,0,0.1), inset 0 1px 0 rgba(255,255,255,0.08)",
              }}
            >
              {Object.entries(protocols).map(([key, info]) => (
                <option key={key} value={key} className="bg-zinc-900 text-white">
                  {info.name} - {info.description}
                </option>
              ))}
            </select>
          </div>

          {protocol === "custom" && (
            <div className="grid grid-cols-3 gap-6 p-6 bg-white/6 rounded-xl backdrop-blur-xl border border-white/12">
              {[
                {
                  key: "inhale",
                  label: "Inhale",
                  value: customTiming.inhale,
                  icon: (
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={1.5}
                        d="M7 16l-4-4m0 0l4-4m-4 4h18"
                      />
                    </svg>
                  ),
                },
                {
                  key: "hold",
                  label: "Hold",
                  value: customTiming.hold,
                  icon: (
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M10 9v6m4-6v6" />
                    </svg>
                  ),
                },
                {
                  key: "exhale",
                  label: "Exhale",
                  value: customTiming.exhale,
                  icon: (
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={1.5}
                        d="M17 8l4 4m0 0l-4 4m4-4H3"
                      />
                    </svg>
                  ),
                },
              ].map(({ key, label, value, icon }) => (
                <div key={key} className="space-y-3 text-center group">
                  <div className="flex items-center justify-center space-x-2">
                    <span className="text-white/50 group-hover:text-white/70 transition-colors duration-300">
                      {icon}
                    </span>
                    <label className="text-xs font-light text-white/60 tracking-[0.1em] uppercase">{label}</label>
                  </div>
                  <input
                    type="number"
                    value={value}
                    onChange={(e) => {
                      const newValue = Math.max(0, Math.min(20, Number.parseInt(e.target.value) || 0))
                      setCustomTiming((prev) => ({ ...prev, [key]: newValue }))
                      customTimingRef.current = { ...customTimingRef.current, [key]: newValue }
                    }}
                    className="w-full p-3 bg-white/8 border border-white/20 rounded-lg backdrop-blur-xl text-center text-white text-lg font-light focus:bg-white/12 focus:border-white/30 focus:outline-none transition-all duration-300 hover:bg-white/10"
                    min="0"
                    max="20"
                    style={{
                      boxShadow: "0 2px 8px rgba(0,0,0,0.1), inset 0 1px 0 rgba(255,255,255,0.08)",
                    }}
                  />
                  <div className="text-xs text-white/40 tracking-wide">seconds</div>
                </div>
              ))}
            </div>
          )}

          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center justify-between p-4 bg-white/6 rounded-xl backdrop-blur-xl border border-white/12 group hover:bg-white/8 transition-all duration-300">
                <div className="flex items-center space-x-4">
                  <svg
                    className="w-4 h-4 text-white flex-shrink-0"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2.5}
                      d="M2 12h2m2-6v12m2-9v6m2-3v0m2-6v12m2-9v6m2-3v0m2-6v12m2-6h2"
                    />
                  </svg>
                  <div>
                    <div className="text-sm font-light text-white/90 tracking-wide">Healing Tones</div>
                    <div className="text-xs text-white/50">Solfeggio frequencies</div>
                  </div>
                </div>
                <button
                  onClick={toggleHealing}
                  className={`w-12 h-6 rounded-full transition-all duration-300 ${
                    healingEnabled ? "atomic-toggle-active" : "atomic-toggle-inactive"
                  }`}
                >
                  <div
                    className={`w-5 h-5 bg-white rounded-full shadow-lg transition-all duration-300 ${
                      healingEnabled ? "translate-x-6" : "translate-x-0.5"
                    }`}
                  />
                </button>
              </div>

              <div className="flex items-center justify-between p-4 bg-white/6 rounded-xl backdrop-blur-xl border border-white/12 group hover:bg-white/8 transition-all duration-300">
                <div className="flex items-center space-x-4">
                  <svg
                    className="w-4 h-4 text-white flex-shrink-0"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2.5}
                      d="M13 10V3L4 14h7v7l9-11h-7z"
                    />
                  </svg>
                  <div>
                    <div className="text-sm font-light text-white/90 tracking-wide">Binaural Beats</div>
                    <div className="text-xs text-white/50">Brainwave entrainment</div>
                  </div>
                </div>
                <button
                  onClick={toggleBinaural}
                  className={`w-12 h-6 rounded-full transition-all duration-300 ${
                    binauralEnabled ? "atomic-toggle-active" : "atomic-toggle-inactive"
                  }`}
                >
                  <div
                    className={`w-5 h-5 bg-white rounded-full shadow-lg transition-all duration-300 ${
                      binauralEnabled ? "translate-x-6" : "translate-x-0.5"
                    }`}
                  />
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between p-4 bg-white/6 rounded-xl backdrop-blur-xl border border-white/12">
              <div className="flex items-center space-x-4">
                <svg className="w-6 h-6 text-white flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <circle cx="12" cy="12" r="3" strokeWidth={2.5} />
                  <circle cx="12" cy="12" r="6" strokeWidth={2.5} />
                  <circle cx="12" cy="12" r="9" strokeWidth={2.5} />
                </svg>
                <div>
                  <div className="text-sm font-light text-white/90 tracking-wide">Breathing Cycles</div>
                  <div className="text-xs text-white/50">Complete repetitions</div>
                </div>
              </div>
              <input
                type="number"
                value={totalCycles}
                onChange={(e) => {
                  const newValue = Math.max(1, Math.min(20, Number.parseInt(e.target.value) || 4))
                  setTotalCycles(newValue)
                  totalCyclesRef.current = newValue
                }}
                className="w-20 p-3 bg-white/8 border border-white/20 rounded-lg text-center text-white text-base font-light focus:bg-white/12 focus:border-white/30 focus:outline-none transition-all duration-300 hover:bg-white/10"
                min="1"
                max="20"
                style={{ boxShadow: "0 2px 8px rgba(0,0,0,0.1), inset 0 1px 0 rgba(255,255,255,0.08)" }}
              />
            </div>
          </div>

          <div className="flex justify-center mt-12">
            <div className="inline-flex items-center space-x-6 p-3 bg-white/4 rounded-lg backdrop-blur-xl border border-white/8">
              {[
                { key: "SPACE", action: "Start/Stop" },
                { key: "1-4", action: "Protocols" },
                { key: "S", action: "Sound" },
                { key: "B", action: "Binaural" },
                { key: "H", action: "Healing Tones" },
                { key: "ESC", action: "Stop" },
              ].map(({ key, action }) => (
                <div key={key} className="flex items-center space-x-1.5 text-xs text-white/40">
                  <kbd
                    className={`px-2 py-1 bg-white/8 border border-white/15 rounded text-white/60 font-mono text-xs ${
                      key === "1-4" ? "min-w-[42px] text-center" : ""
                    }`}
                  >
                    {key}
                  </kbd>
                  <span className="font-light">{action}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
